<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'df1b3cc0f08ca0f596168b09a7796f83',
      'native_key' => 'linguapdotools',
      'filename' => 'modNamespace/e9203f0a29ba8866735d8dd5165b352f.vehicle',
      'namespace' => 'linguapdotools',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bbbb5e1d0bb12efe6f20eaab3296d273',
      'native_key' => 1,
      'filename' => 'modCategory/5544787b172b24f49bfcc6d575e6b6e7.vehicle',
      'namespace' => 'linguapdotools',
    ),
  ),
);